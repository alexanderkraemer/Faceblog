<div id="error-container">
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2 text-center">
            <h1 ><i class="gi gi-circle_exclamation_mark text-warning"></i></h1>
            <h2>Falsche Eingabe!</h2>
            <h4>Route nicht vorhanden!!</h4>
        </div>
        <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
        </div>
    </div>
</div>