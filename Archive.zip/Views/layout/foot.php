<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo DIR; ?>/assets/js/jquery.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo DIR; ?>/assets/js/bootstrap.min.js"></script>

</body>
</html>