<?php

    class Base
    {
        function __construct ()
        {
            $this->page = new Page();
        }
    }